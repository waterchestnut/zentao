<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPr1vuGHHmDahbCzq9/ncSozJeSg0aD5HCFG/c/cKt3hkyTAGT/7Sf0niAyQrr6Wzn7cBSBXx
58hl4E5MunQ2VYHkJTgKw/gngUlW3NGGaG6SRQeaOLaie1purHKblBisd8aTpVMa8zwF9xzOitGc
l/2qgflTdM9OfR9DCX/k8ElV4Jut3NYLaUloDdQkAh3PqqEADdskfK5laq9b96Ax+3IXkY2a8JTk
2UyKeCd1J8vAgTUF415wsLHZL8F1TDu3aXkJqd4BX5KUJKbrCrzda7C9RXsBgzomrQnOZ4LN1myW
uh9x3Wx8o0wkTXA+SLJdyYYt3Dhy06goCiJEBaQh8Hmt6K/ZE17wP9wcIuQbsInkM6+zf/Nnwunj
UFWOD8rOsb3iXJKT5HwiAy6QEIsBJmfLyhzdyBEMdzZzHUfheHB9IWeH+YCvoagIYuTJhRPDoVt6
/B027r1XhIG6ENSNgWZyt/Tm4XlRE9L/YEP0LxqMynBd6tpog87V2XbbP83e6KeOCDNuInGlrRPr
XIz7mBraVN4a7klvp7gWp96qamz3Vs0/ynmEaLW5LILV4oYxFRY5+U9rhWIEO8t29dFdJRmtV7vE
h+gDeA085cqf15ribT8CJVz2Dl58SuBCDcX4t09ml13bJTiZxgNMoPjnoLor/mZK3R5Ds2iWO8zX
6N1A0+VcThhiOuDyYc1thNjMN6bC9xtLnepLHaEQi8Dxa3C+lCt6fYB9xPvWPGm1CGmsLCzz/WKX
vPs0ylG1v50xZ8MTc+lk79e4n1fE3JxBMxguReAHHZTWJPPvlBBNFu6QieJkL1FLHke4L0E5D4bM
aO8/59cFXIf07HXoWlrGCECermfLQuE6beRqabokGaiMr9rexhtdV0jpYaMZjTIBL0W+FzyurYSu
bWvAxJPF7wa65hMy/dkaDcYCDp0p1BQogmSxAoeP4o+xViW0FwJh9TZEag21kGWTAf7/LFe2CvJU
vWKZvNOrXP8106X2cclsMBpSnBeYZpKuDgF55bonhOwKoIClS84pK9zK+tOsOjt3DWq3RP636mEx
0PifZl1cd2xurpCHkaPp6H27bknFYjn7RIz9EJ4rCXAii+ILrR59MoUGoG3kdz8+32G0EF2rIrVy
azW1NweuVc/WqmZkg2U3KLP220PSsFflG+Duqwtw3lFl