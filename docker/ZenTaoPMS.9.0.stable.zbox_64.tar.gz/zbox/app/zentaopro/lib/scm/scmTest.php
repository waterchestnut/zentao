<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPvfzXAS3n7o8OiiHX9gee2x03lkDWLiMUTOGr402OqbUNGip1HNwtWyRYpSoophpVfm5etSs
wk/+L2iUT83Q8Q6BJWeURDeXCuW/xw17s+1J4nnufqiAH/WA55bJbM8DZs3MXMhN1A/9+4mUpDtw
NELfk54Zf1C2fL1hgA4BL0+Unxn+E0FORnBlf3G7aLRlDENa9Ed09tDdK57XsTh5InNiUhliCGTt
uTa3EZZlkAm1iNXHMjC9kUNm6YO6QZGnr1B5aZdYB5lHVjcmCLTdmSjjXuh6xGuD/JqWd8aSeoPp
ntrtTIxX+Z06bADf+hBDe41AV0Q3ms2gkf1/j+ZLlFQCKis3UftupYKWnM1G3c+L329zsioSHnln
FsyThbk8/+hTXDt7iJMEEZhnMY0msSTisRj5w5pSbwITTrTjfukpftgLKg+t0Q6O8EoL6ew9q/EE
+uYnNEkRQQqtYoNvW63/f4dPc7lPOBH9pCIA2h0E6XB+zSROGNT4sZgBDnE0u1AzAXjtqP6xBGPG
e2PuKqE9G40wkCmIAcJoTpkoMoCVDImUuDDgWmGoAMcoDB1jIHOltdsKg4UPOyKRH8ZngERHgxu+
1YpVr7F+aATQ8PW8+hRTDHrOI4fdAXtbQp81JQajJ7Eu5dfTGqlrOqWH0XjhhoMzy3uEEA7tQTF3
2/ECVMj0KEY46vkGf2ibXWdbpjpvfnmglgGA64Ovq6UwKLb1tidq0LF98egP0buoTU93VtnElS2L
Tmg+eWC+8oIZb0fIQFfFaNANec0CVufZzjfXaB5yUcg26OQ6gOjKwpR3sHNLllxPUic3Fdb5K6qe
h66tvl04uIfznGQ2ZBkKamjNd1iwADMbsoLbPODZTiVCsqsg+B67OCzPu7hBqX2fgsBXLM4Ow2vI
hHR8c0UQems7I/czv+K/Ab9Vuz3IeTOQklO7IHnQLzRuvh7owhN99sDMt7enuAUsZOwczTQ88O6I
TiXtQCvW4gXFTAcOSnUg5vyY86k/ruNvmAeVyLLyXfv3Z2SQmlg0qdezcuYsOX0XJhXwYqUF2h2I
BHlGNzKitK+5r5YkcHAZz4HApZPjAA4rvOXYKNOE5q754d1XNsaknVKOzyROkgAW2vppLRAwfN0L
/4BNZ+EePa4T1HFpOeIP8t5HBoj8LdW3C133svzTMhPj3LYxVdpaEAYA8N6z