<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPya4VCBsxqJsDxBfuU6idOXj7LsA0DHqFjsHnBxitYE+E/hAfZa74iTkLixK0qlpT+mDmhBK
LoMnX4XwzqqSpvlbHyfMS1nQ2VJ304mDXO0Ws3Gi+0SXS7Z+KQuKGEci1YQ3KCC4qfV/TLWkkDVo
lo9SKAzxdk0+x04Mtp0721g9/jRJLyXc9RmWwn031PTdxx4wGwGI5Exlt1OswlEp8AaPknXb+jcS
MlkF781kQXS+utQKD1gsda8D9a7iRwXGOLQgrNNpHPlXMVMI3Ij6e9PmKArSt2cqAFoXmm+CRFmZ
Kk65YANmtu4gov2YCvQiPa7dBr5mVDaeRUSWHDT/9HKxGpQTRgMfPesnRS+HFwTgTfeMcvmhNc65
6DazZ8A4DJGisG/7sOsc3ao/9p2JxneezYp4+LVlIuOoShzTS6z8viKmTdhExjUw9arymkiqWCFM
p3w6FKmaneFjRV+7B3tEVNrAfLV9lrEktRZXGU/8aRXdBYV6hvJHpVM/gfm4YauiZfNvrB1UrIQP
vpB9E04AAEwcqsSHDJTpbSqotD5ak4itZP2d+QxQkxaOYTDpz90U2Uvvvye8qHrQYVuPezSQm3KL
vll1VjYRVjqDhvP9Uv/j7k3O2kZ7BkT18bDoYfvmO0YDO9YdHLVNKF4xDGUhx7ncGb5Ey4ZSjR1f
8NBRloDedXAsfkXwWnVxPb0V3DDbfa84tjodX9kcpOOQawG751mmHGDNkpk8kvH6/bj24y14bz4e
da5VhdgyABQUqpxbZCw23LRhllQ36ZNz5TWNf3v1bRQdc83QpYriieT6+Oz9VWFl1eG6RLOZM6NP
4Gs4yrlVIVaWosgmRZBNEvry5R0URC23k4k/FS2HajF6cHKYnzRRMtN9pJG4vD8MOKI8iS/PwabC
ptC+iz+P0Arl9ROdHvcDThwkrBaFNWOxHhDGrKCavv2ccAzvPWI1q3M21x5+sAhflB1k4ZcnIaQR
hBDkJCd/1xuo+2arah9fP72arChA7jIWncEdJRLr5yn9HloXOdct7pRkSiW4iiZomThGaWh3v5aM
fGFZ1yk5l+fX26PNVyDrH888Qmr13TKEWX4n4nT3Xi6WcLOmGaHj4QTK+uiHCOcffVaiHnRVBG+q
d/qou+PE1Ehq7tNuEHJvQdrICf6zFGiLPyqS0Fjo2wDZEgQp9IPz